#include "Ship.h"

Ship::Ship()
{
}

Ship::~Ship()
{
}

void Ship::Draw(void)
{
}

void Ship::Updata(void)
{
}

Vector2 Ship::GetSize(void)
{
	return Vector2();
}

bool Ship::Init(void)
{
	return true;
}
