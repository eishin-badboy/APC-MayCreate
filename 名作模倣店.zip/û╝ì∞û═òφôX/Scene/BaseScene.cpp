#include "BaseScene.h"


BaseScene::~BaseScene()
{
}
